# Application Environment Setup

1. Install Anaconda

2. Create and Activate Environment:
   - Navigate to the directory with `app_env.yaml`.
   - Create the environment: `conda env create -f app_env.yaml`
   - Activate the environment: `conda activate app_env`

3. Run the Server

