from flask import Flask, request, jsonify
from flask_cors import CORS
import util

app = Flask(__name__)
CORS(app)
util.load_artifacts()

@app.route('/get_house_types')
def get_house_types():
    response = jsonify({
        'options': util.get_house_types()
    })
    # response.headers.add('Access-Control-Allow-Origin', '*')
    return response

@app.route('/get_hold_types')
def get_hold_types():
    response = jsonify({
        'options': util.get_hold_types()
    })
    # response.headers.add('Access-Control-Allow-Origin', '*')
    return response
@app.route('/predict_house_price', methods=['POST'])
def predict_house_price():

    housetype = request.form['housetype']
    postcode = (request.form['postcode'])
    beds = float(request.form['beds'])
    baths = float(request.form['baths'])
    reception = float(request.form['reception'])
    balcony = bool(request.form['balcony'])
    gym = bool(request.form['gym'])
    garden = bool(request.form['garden'])
    garage = bool(request.form['garage'])
    holdtype = request.form['holdtype']
    distancefromschool1 = float(request.form['distancefromschool1'])
    distancefromschool2 = float(request.form['distancefromschool2'])
    distancefromstation1 = float(request.form['distancefromstation1'])
    distancefromstation2 = float(request.form['distancefromstation2'])
    description = (request.form['description'])
    estimated = util.get_estimated_price(description, beds, baths, reception, holdtype, balcony, gym,
                                         garden, garage, distancefromschool1, distancefromschool2, distancefromstation1,
                                         distancefromstation2, postcode, housetype)
    estimated_price = float(estimated)
    response = jsonify({
        'estimated_price': estimated_price
    })

    # response.headers.add('Access-Control-Allow-Origin', '*')
    return response
@app.route('/get_best_houses', methods=['POST'])
def get_best_houses():
    post_code = (request.form['postcode'])
    budget = float(request.form['budget'])
    miles = float(request.form['miles'])
    best_properties = util.search_best_10_properties(post_code, budget, miles)
    response = jsonify({
        'best_properties': best_properties
    })

    return response


if __name__ == "__main__":
    print("starting server")
    util.load_artifacts()
    app.run()