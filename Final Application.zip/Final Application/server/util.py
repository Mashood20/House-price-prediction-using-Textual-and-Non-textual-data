import json
import pickle
# import xgboost
import catboost
import pgeocode
import numpy as np
import pandas as pd
import joblib
import nltk
nltk.download('stopwords')
nltk.download('wordnet')
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import RegexpTokenizer
from nltk.corpus import stopwords
import re

__housetype = None
__holdtype = None
__model = None
__datacolumns = None
__df = None
__scaler = None
__tfidf = None

tokeniser = RegexpTokenizer(r'\w+')
lemmatiser = WordNetLemmatizer()

stopwords_nltk=stopwords.words('english')
real_estate_stopwords = ["area", "flat", "house", "gbp", "province", "location", "plot", "hectare", "acre", "m²", "m2", "sq", "sale", "square", "meter", "metre", "feet", "ft", "sqft", "foot", "room", "bedroom", "bathroom", "bath", "washroom", "dining", "living", "kitchen", "hallway", "corridor", "extra"]
stop_words=stopwords_nltk+real_estate_stopwords

def preprocess_text(text):
    text = text.lower()
    # # Remove non-alphanumeric characters except spaces
    # text = re.sub(r'[^a-zA-Z0-9\s]', '', text)
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    # Remove single alphabets
    text = re.sub(r'\b\w{1}\b', '', text)
    # Replace multiple spaces with one
    text = re.sub(r'\s+', ' ', text)
    # Tokenize text using the tokenizer
    tokens = tokeniser.tokenize(text)
    # Lemmatising text
    lemmatised = [lemmatiser.lemmatize(str(token)) for token in tokens]
    # Remove Stop words
    clean_text = [token for token in lemmatised if token not in stop_words]
    return ' '.join(clean_text)


def encoded_description(description):
    preprocessed_text = preprocess_text(description)
    tfidf_processed = __tfidf.transform([preprocessed_text])
    embeddings = pd.DataFrame(tfidf_processed.toarray())
    return embeddings

def encoded_descriptions(description):
    tfidf_processed = __tfidf.transform(description)
    embeddings = pd.DataFrame(tfidf_processed.toarray())
    return embeddings

def get_lat(postal_code):
    nomi = pgeocode.Nominatim('GB')
    location = nomi.query_postal_code(postal_code)
    return location.latitude

def get_lon(postal_code):
    nomi = pgeocode.Nominatim('GB')
    location = nomi.query_postal_code(postal_code)
    return location.longitude

def get_estimated_price(description, beds, baths, receptions, holdtype, Balcony, Gym, Garden, Garage,school1, school2, station1, station2, postcode, housetype):

    try:
        type_index = __datacolumns.index(housetype.lower())-1
    except:
        type_index = -1
    try:
        type_hold_index = __datacolumns.index(holdtype)-1
    except:
        type_hold_index = -1

    x = np.zeros(len(__datacolumns)-1)
    x[0] = beds
    x[1] = baths
    x[2] = receptions
    if type_hold_index >= 0:
        x[type_hold_index] = 1
    x[6] = Balcony
    x[7] = Gym
    x[8] = Garden
    x[9] = Garage
    x[10] = school1
    x[11] = school2
    x[12] = station1
    x[13] = station2
    x[14] = get_lat(postcode)*0.01
    x[15] = get_lon(postcode)*0.01
    if type_index >= 0:
        x[type_index] = 1
    num_features = x.reshape(1, -1)
    num_df = pd.DataFrame(num_features)
    numerical_columns = [0, 1, 2]
    num_df.iloc[:, numerical_columns] = __scaler.transform(num_df.iloc[:, numerical_columns])
    print(num_df.iloc[:, numerical_columns])
    text_embed = encoded_description(description)
    print(num_features.shape)
    print(text_embed.shape)
    combo = np.concatenate((num_df, text_embed), axis=1)
    com = combo.flatten()
    result = np.expm1(__model.predict([com])[0])

    return np.round(result/10000)*10000

def getdata():

    df = pd.read_csv('./artifacts/preprocessed.csv')
    print(df.columns)
    return df


def search_best_10_properties(postcode, budget, miles):
    df = __df
    postcode_lat = get_lat(postcode)*0.01
    postcode_lon = get_lon(postcode)*0.01
    # radius in degrees
    radius_deg = float((miles/69)*0.01)  # 1 degree of latitude is approximately 69 miles, so 0.5 miles is about 0.00714 degrees

    # Filter the DataFrame to include only rows within the specified radius
    f_df = df[
        (df['latitude'] >= postcode_lat - radius_deg) &
        (df['latitude'] <= postcode_lat + radius_deg) &
        (df['longitude'] >= postcode_lon - radius_deg) &
        (df['longitude'] <= postcode_lon + radius_deg) &
        (df['price'] <= budget)
        ].copy()

    if len(f_df) >= 1:
        print(f_df.shape, 'embedstart')
        f_df['description_text'] = f_df['description_text'].apply(preprocess_text)
        embeddings = encoded_descriptions(f_df['description_text'])
        print('embedend')
        f1_df = f_df.drop(['description_text', 'average_sale_price', 'log_trans_avg_price', 'log_trans_price','price', 'url'], axis=1)
        df_combo = np.concatenate((f1_df, embeddings), axis=1)
        f_df['predicted_price'] = __model.predict(df_combo)
        f_df['price_difference'] = f_df['predicted_price'] - f_df['price']
        f_df = f_df.sort_values(by='price_difference', ascending=False).head(10)

        best = f_df['url'].tolist()
        print(best)
        return best
    else:

        print('no properties found')
        return "No properties found"

def get_house_types():
    return __housetype
def get_hold_types():
    return __holdtype

def load_artifacts():
    global __datacolumns
    global __housetype
    global __model
    global __holdtype
    global __df
    global __scaler
    global __tfidf

    with open("./artifacts/columns.json",'r') as f:
        __datacolumns = json.load(f)['data_columns']
        __housetype = __datacolumns[17:]
        __holdtype = __datacolumns[4:7]

    with open("./artifacts/catboost_tfidf_model.pkl",'rb') as f:
        __model = pickle.load(f)

    with open("./artifacts/scaler_model.joblib", 'rb') as f:
        __scaler = joblib.load(f)

    with open("./artifacts/tfidf_model.joblib", 'rb') as f:
        __tfidf = joblib.load(f)


    __df = getdata()

    print('artifacts loaded')

if __name__ ==  '__main__':
    load_artifacts()


