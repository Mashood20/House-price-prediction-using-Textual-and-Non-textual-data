function showLoading() {
    $("#loading").show();
}

function hideLoading() {
    $("#loading").hide();
}

function getbed(){
    var uibeds =  document.getElementsByName('uibeds')
    for(var i in uibeds){
        if(uibeds[i].checked){
            return parseInt(i)+1;  
        }
    }
    return -1
}
function getbathroom(){
    var uiBathrooms =  document.getElementsByName('uiBathrooms')
    for(var i in uiBathrooms){
        if(uiBathrooms[i].checked){
            return parseInt(i)+1;  
        }
    }
    return -1
}

function getreception(){
    var uireception =  document.getElementsByName('uireception')
    for(var i in uireception){
        if(uireception[i].checked){
            return uireception[i].value;  
        }
    }
    return -1
}
function getgarden(){
    var uigarden =  document.getElementsByName('uigarden')
    for(var i in uigarden){
        if(uigarden[i].checked){
            return uigarden[i].value;  
        }
    }
    return -1
}
function getgarage(){
    var uigarage =  document.getElementsByName('uigarage')
    for(var i in uigarage){
        if(uigarage[i].checked){
            return uigarage[i].value;  
        }
    }
    return -1
}
function getbalcony(){
    var uibalcony =  document.getElementsByName('uibalcony')
    for(var i in uibalcony){
        if(uibalcony[i].checked){
            return uibalcony[i].value;  
        }
    }
    return -1
}
function getgym(){
    var uigym =  document.getElementsByName('uigym')
    for(var i in uigym){
        if(uigym[i].checked){
            return uigym[i].value;
        }
    }
    return -1
}

function getschool1(){
    var school1 = document.getElementById('uischool1');

    if(school1 !== null){
        return school1;
    }

    return -1
}
function getschool2(){
    var school2 = document.getElementById('uischool2');

    if(school2 !== null){
        return school2;
    }
    return -1
}
function getstation1(){
    var station1 = document.getElementById('uistation1');

    if(station1 !== null){
        return station1;
    }
    return -1
}
function getstation2(){
    var station2 = document.getElementById('uistation2');

    if(station2 !== null){
        return station2;
    }
    return -1
}



function EstimatePrice() {
    showLoading();
    var housetype = document.getElementById('uihousetype');
    var postcode = document.getElementById('postcode');
    var beds = getbed();
    var bathrooms = getbathroom();
    var reception = getreception();
    var garden = getgarden();
    var garage = getgarage();
    var balcony = getbalcony();
    var gym = getgym();
    var holdtype = document.getElementById('uiholdingtype');
    var school1 = getschool1();
    var school2 = getschool2();
    var station1 = getstation1();
    var station2 = getstation2();
    var description = document.getElementById('uidescription');
    var estimatedprice = document.getElementById('uiEstimatedPrice');

    // Convert the postcode to uppercase and check if it matches a  postcode pattern
//    var postcodeValue = postcode.value.trim().toUpperCase();
//    var postcodePattern = /^[A-Z]{1,2}[0-9R][0-9A-Z]?[0-9][ABD-HJLNP-UW-Z]{2}$/;

//    if (!postcodePattern.test(postcodeValue)) {
//        postcodeError.textContent = "Please enter a valid and full postcode.";
//        postcodeError.style.color = "red";
//        hideLoading();
//        return;
//    } else {
//        postcodeError.textContent = "";
//    }



    // Check if the description contains at least 50 words
    var wordCount = countWords(description.value);

    if (wordCount < 30) {
        wordCountMessage.textContent = "Description must contain at least 30 words.";
        wordCountMessage.style.color = "red"; // Set the color to red
        hideLoading(); // Ensure loading indicator is hidden
        return; // Exit the function
    } else {
        wordCountMessage.textContent = ""; // Clear the message
    }

    // data iam sending
    var requestData = {
        housetype: housetype.value,
        postcode: postcode.value,
        beds: beds,
        baths: bathrooms,
        reception: parseInt(reception),
        garden: parseInt(garden),
        garage: parseInt(garage),
        balcony: parseInt(balcony),
        gym: parseInt(gym),
        holdtype: holdtype.value,
        distancefromschool1: parseFloat(school1.value),
        distancefromschool2: parseFloat(school2.value),
        distancefromstation1: parseFloat(station1.value),
        distancefromstation2: parseFloat(station2.value),
        description: description.value
    };

    // Log the data before making the POST request
    console.log('Data to be sent:', requestData);

    var url = "http://127.0.0.1:5000/predict_house_price";

    // POST request with the requestData
    $.post(url, requestData, function (data, status) {
        console.log(data.estimated_price);
        estimatedprice.innerHTML = "<h1> £" + data.estimated_price.toString() + "<h1/>";
        console.log(status);
        hideLoading();
    });
}


function countWords(text) {
    const words = text.trim().split(/\s+/);
    return words.length;
}

function findbestproperties(){
    showLoading();
    var postcode = document.getElementById('best_postcode');
    var radius = document.getElementById('radius');
    var budget = document.getElementById('budget')

    var propertyList = document.getElementById("propertyList");
        // Convert the postcode to uppercase and check if it matches a  postcode pattern

    var requestData = {
    postcode: postcode.value,
    budget: budget.value,
    miles: miles.value
    };

    var url = "http://127.0.0.1:5000/get_best_houses";

    $.post(url, requestData, function(data, status){
        console.log(data.best_properties);
        propertyList.innerHTML = '';
        var propertyLinks = data.best_properties;
        console.log(status);

        propertyLinks.forEach(function (link) {
                var listItem = document.createElement("li");
                var anchor = document.createElement("a");
                anchor.href = link; // Set the link URL
                anchor.textContent = "Property Link";
                anchor.target = "_blank";
                listItem.appendChild(anchor);
                propertyList.appendChild(listItem);
                hideLoading();
        });

    });


}

function onPageLoad() {
    Dropdown("uihousetype","http://127.0.0.1:5000/get_house_types")
    Dropdown("uiholdingtype","http://127.0.0.1:5000/get_hold_types")
}

function Dropdown(id,url) {
    console.log( "document loaded" );

    $.get(url,function(data, status) {
        console.log("got response for get_location_names request");
        if(data) {
            var type = data.options;
            var uitype = document.getElementById(id);
            $('#'+id).empty();
            for(var i in type) {
                var opt = new Option(type[i]);
                $('#'+id).append(opt);
            }
        }
    });
}
  
window.onload = onPageLoad;